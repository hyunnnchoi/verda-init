#!/usr/bin/env bash
# exp_a.sh — Experiment A: ONE 4-GPU job split 2+2 across 2 nodes.
#
# Usage:
#   bash launchers/exp_a.sh <model> [TOTAL_STEPS] [GPUS_PER_NODE]
#
# Default GPUS_PER_NODE=2 (production: A100 x4 nodes, half used per job).
# For today's 1xA100 nodes, override with GPUS_PER_NODE=1 to smoke test.

set -eo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJ_ROOT="$(cd "$ROOT_DIR/.." && pwd)"

MODEL="${1:?Usage: $0 <model> [TOTAL_STEPS] [GPUS_PER_NODE]}"
TOTAL_STEPS="${2:-200}"
GPUS_PER_NODE="${3:-2}"

MAIN_NODE="${MAIN_NODE:-main1}"
SUB_NODE="${SUB_NODE:-sub1}"
PORT="${PORT:-29400}"

EXP_ID="${EXP_ID:-expA_${MODEL}_$(date +%Y%m%d_%H%M%S)}"
JOB_ID="${JOB_ID:-job0_${MODEL}}"
BARRIER_DIR="${BARRIER_DIR:-${ROOT_DIR}/.barrier_${EXP_ID}}"

echo "============================================"
echo " Experiment A — single job, 4 GPUs across 2 nodes"
echo "   model           = ${MODEL}"
echo "   total steps     = ${TOTAL_STEPS}"
echo "   gpus per node   = ${GPUS_PER_NODE}  (-> ${GPUS_PER_NODE}+${GPUS_PER_NODE} ranks)"
echo "   nodes           = ${MAIN_NODE} + ${SUB_NODE}"
echo "   master port     = ${PORT}"
echo "   exp id          = ${EXP_ID}"
echo "============================================"

# Clean barrier dir
rm -rf "$BARRIER_DIR"; mkdir -p "$BARRIER_DIR"

env_common=(
  MODEL="$MODEL"
  EXP_ID="$EXP_ID"
  JOB_ID="$JOB_ID"
  PEER_JOB_IDS=""
  BARRIER_DIR="$BARRIER_DIR"
  MASTER_ADDR="$MAIN_NODE"
  MASTER_PORT="$PORT"
  NNODES=2
  GPUS_PER_NODE="$GPUS_PER_NODE"
  GPU_OFFSET=0
  TOTAL_STEPS="$TOTAL_STEPS"
)

# Launch sub1 (rank 1) first in background; then main1 (rank 0).
ssh "$SUB_NODE" "${env_common[*]} NODE_RANK=1 bash ${ROOT_DIR}/launchers/launch_worker.sh" &
SUB_PID=$!
sleep 1
env "${env_common[@]}" NODE_RANK=0 bash "${ROOT_DIR}/launchers/launch_worker.sh"
MAIN_RC=$?
wait "$SUB_PID" || true
SUB_RC=$?

echo "[exp_a] main rc=${MAIN_RC} sub rc=${SUB_RC}"
echo "[exp_a] results -> ${ROOT_DIR}/results/${EXP_ID}/${JOB_ID}/"
exit $(( MAIN_RC + SUB_RC ))
