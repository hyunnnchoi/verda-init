#!/usr/bin/env bash
# exp_b.sh — Experiment B: TWO 4-GPU jobs co-located across 2 nodes.
#
# Usage:
#   bash launchers/exp_b.sh <model_a> <model_b> [TOTAL_STEPS] [GPUS_PER_NODE_PER_JOB]
#
# GPUS_PER_NODE_PER_JOB defaults to 2 (production: 4 GPUs per node split into
# 2 jobs of 2 GPUs each per node). On today's 1xA100 nodes you can pass 1
# (each node hosts one rank of each job; you'll need 2 GPUs per node — so
# this only smoke-tests if both jobs can share the single GPU; effectively
# you should use exp_a.sh for today's hardware).

set -eo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

MODEL_A="${1:?Usage: $0 <model_a> <model_b> [TOTAL_STEPS] [GPUS_PER_NODE_PER_JOB]}"
MODEL_B="${2:?Usage: $0 <model_a> <model_b> [TOTAL_STEPS] [GPUS_PER_NODE_PER_JOB]}"
TOTAL_STEPS="${3:-200}"
GPUS_PER_NODE_PER_JOB="${4:-2}"

MAIN_NODE="${MAIN_NODE:-main1}"
SUB_NODE="${SUB_NODE:-sub1}"
PORT_A="${PORT_A:-29400}"
PORT_B="${PORT_B:-29401}"

EXP_ID="${EXP_ID:-expB_${MODEL_A}+${MODEL_B}_$(date +%Y%m%d_%H%M%S)}"
JOB_A="${JOB_A:-job0_${MODEL_A}}"
JOB_B="${JOB_B:-job1_${MODEL_B}}"
BARRIER_DIR="${BARRIER_DIR:-${ROOT_DIR}/.barrier_${EXP_ID}}"

echo "============================================"
echo " Experiment B — two co-located jobs"
echo "   job A           : ${JOB_A} (model=${MODEL_A}, port=${PORT_A})"
echo "   job B           : ${JOB_B} (model=${MODEL_B}, port=${PORT_B})"
echo "   gpus/node/job   : ${GPUS_PER_NODE_PER_JOB}  (-> ${GPUS_PER_NODE_PER_JOB}+${GPUS_PER_NODE_PER_JOB} per job, ${GPUS_PER_NODE_PER_JOB}*2 per node)"
echo "   total steps     : ${TOTAL_STEPS}"
echo "   nodes           : ${MAIN_NODE} + ${SUB_NODE}"
echo "   exp id          : ${EXP_ID}"
echo "============================================"

rm -rf "$BARRIER_DIR"; mkdir -p "$BARRIER_DIR"

# Job A: GPU offset 0, peers=[JOB_B]
env_a_common=(
  MODEL="$MODEL_A" EXP_ID="$EXP_ID" JOB_ID="$JOB_A" PEER_JOB_IDS="$JOB_B"
  BARRIER_DIR="$BARRIER_DIR" MASTER_ADDR="$MAIN_NODE" MASTER_PORT="$PORT_A"
  NNODES=2 GPUS_PER_NODE="$GPUS_PER_NODE_PER_JOB" GPU_OFFSET=0
  TOTAL_STEPS="$TOTAL_STEPS"
)

# Job B: GPU offset = GPUS_PER_NODE_PER_JOB by default (each job claims a
# disjoint slice of GPUs on each node). Override with GPU_OFFSET_B for the
# 1-GPU-per-node smoke case where both jobs must share the same device.
GPU_OFFSET_B="${GPU_OFFSET_B:-$GPUS_PER_NODE_PER_JOB}"
env_b_common=(
  MODEL="$MODEL_B" EXP_ID="$EXP_ID" JOB_ID="$JOB_B" PEER_JOB_IDS="$JOB_A"
  BARRIER_DIR="$BARRIER_DIR" MASTER_ADDR="$MAIN_NODE" MASTER_PORT="$PORT_B"
  NNODES=2 GPUS_PER_NODE="$GPUS_PER_NODE_PER_JOB" GPU_OFFSET="$GPU_OFFSET_B"
  TOTAL_STEPS="$TOTAL_STEPS"
)

# Sub1 sides (rank 1 of both jobs) in background
ssh "$SUB_NODE" "${env_a_common[*]} NODE_RANK=1 bash ${ROOT_DIR}/launchers/launch_worker.sh" &
SUB_A_PID=$!
ssh "$SUB_NODE" "${env_b_common[*]} NODE_RANK=1 bash ${ROOT_DIR}/launchers/launch_worker.sh" &
SUB_B_PID=$!
sleep 1

# Main1 sides (rank 0 of both jobs) in background, wait at end
env "${env_a_common[@]}" NODE_RANK=0 bash "${ROOT_DIR}/launchers/launch_worker.sh" &
MAIN_A_PID=$!
env "${env_b_common[@]}" NODE_RANK=0 bash "${ROOT_DIR}/launchers/launch_worker.sh" &
MAIN_B_PID=$!

wait "$MAIN_A_PID"; MA_RC=$?
wait "$MAIN_B_PID"; MB_RC=$?
wait "$SUB_A_PID";  SA_RC=$?
wait "$SUB_B_PID";  SB_RC=$?

echo "[exp_b] rc: mainA=$MA_RC mainB=$MB_RC subA=$SA_RC subB=$SB_RC"
echo "[exp_b] results -> ${ROOT_DIR}/results/${EXP_ID}/{${JOB_A},${JOB_B}}/"
exit $(( MA_RC + MB_RC + SA_RC + SB_RC ))
