#!/usr/bin/env bash
# launch_worker.sh — launch ONE DDP job on ONE node.
#
# Required env vars:
#   MODEL                 e.g. bert
#   EXP_ID                experiment instance id
#   JOB_ID                unique id for this DDP job
#   PEER_JOB_IDS          comma-separated co-located peer ids (or empty)
#   BARRIER_DIR           shared-FS path for cross-job ready/done sentinels
#   OUTPUT_ROOT           where rank-N json files land
#   MASTER_ADDR           hostname for rank 0 (the rank-0 node)
#   MASTER_PORT           TCPStore port for this job
#   NNODES                total nodes participating in this job
#   NODE_RANK             which node we are (0-indexed within this job)
#   GPUS_PER_NODE         processes-per-node for THIS job on THIS node
#   GPU_OFFSET            starting CUDA device index for this job on this node
#                         (e.g. job 0 -> 0, job 1 -> GPUS_PER_NODE)
#
# Optional:
#   TOTAL_STEPS, WARMUP_STEPS, SAMPLE_COMPUTE_EVERY, PROFILE_FIRST_N,
#   BATCH_SIZE_OVERRIDE, EXTRA_ARGS, NCCL_DEBUG, NCCL_SOCKET_IFNAME

set -eo pipefail

: "${MODEL:?MODEL is required}"
: "${EXP_ID:?EXP_ID is required}"
: "${JOB_ID:?JOB_ID is required}"
: "${MASTER_ADDR:?MASTER_ADDR is required}"
: "${MASTER_PORT:?MASTER_PORT is required}"
: "${NNODES:?NNODES is required}"
: "${NODE_RANK:?NODE_RANK is required}"
: "${GPUS_PER_NODE:?GPUS_PER_NODE is required}"
: "${GPU_OFFSET:=0}"
: "${PEER_JOB_IDS:=}"
: "${BARRIER_DIR:=/home/work/hyunmokchoi/mosim-llms/A100_multinode/.barrier_${EXP_ID}}"
: "${OUTPUT_ROOT:=/home/work/hyunmokchoi/mosim-llms/A100_multinode/results}"
: "${TOTAL_STEPS:=200}"
: "${WARMUP_STEPS:=10}"
: "${SAMPLE_COMPUTE_EVERY:=5}"
: "${PROFILE_FIRST_N:=0}"
: "${EXTRA_ARGS:=}"

# Build CUDA_VISIBLE_DEVICES = GPU_OFFSET, GPU_OFFSET+1, ..., GPU_OFFSET+GPUS_PER_NODE-1
gpu_list=""
for ((i=0; i<GPUS_PER_NODE; i++)); do
    [[ -n "$gpu_list" ]] && gpu_list+=","
    gpu_list+="$((GPU_OFFSET + i))"
done

# HF cache + offline mode (matches existing experiments)
export HF_HOME=${HF_HOME:-/home/work/hyunmokchoi/hf_cache}
export HF_DATASETS_CACHE=${HF_DATASETS_CACHE:-/home/work/hyunmokchoi/hf_cache}
export TRANSFORMERS_CACHE=${TRANSFORMERS_CACHE:-/home/work/hyunmokchoi/hf_cache}
export HF_DATASETS_OFFLINE=${HF_DATASETS_OFFLINE:-1}
export TRANSFORMERS_OFFLINE=${TRANSFORMERS_OFFLINE:-1}
export HF_HUB_OFFLINE=${HF_HUB_OFFLINE:-1}

# NCCL: route bootstrap over the overlay, let the IBext plugin pick the IB NIC
export NCCL_SOCKET_IFNAME=${NCCL_SOCKET_IFNAME:-eth0}

LOG_DIR=${LOG_DIR:-/home/work/hyunmokchoi/mosim-llms/A100_multinode/logs}
mkdir -p "$LOG_DIR" "$BARRIER_DIR" "$OUTPUT_ROOT"

LOG_FILE="${LOG_DIR}/${EXP_ID}_${JOB_ID}_node${NODE_RANK}.log"
echo "[launch_worker] EXP=${EXP_ID} JOB=${JOB_ID} node=${NODE_RANK}/${NNODES} gpus=${gpu_list} -> ${LOG_FILE}"

cd /home/work/hyunmokchoi/mosim-llms

CUDA_VISIBLE_DEVICES="$gpu_list" \
torchrun \
  --nnodes="$NNODES" \
  --node_rank="$NODE_RANK" \
  --nproc_per_node="$GPUS_PER_NODE" \
  --master_addr="$MASTER_ADDR" \
  --master_port="$MASTER_PORT" \
  --rdzv_backend=c10d \
  --rdzv_endpoint="${MASTER_ADDR}:${MASTER_PORT}" \
  A100_multinode/train.py \
    --model "$MODEL" \
    --exp-id "$EXP_ID" \
    --job-id "$JOB_ID" \
    --peer-job-ids "$PEER_JOB_IDS" \
    --barrier-dir "$BARRIER_DIR" \
    --output-root "$OUTPUT_ROOT" \
    --total-steps "$TOTAL_STEPS" \
    --warmup-steps "$WARMUP_STEPS" \
    --sample-compute-every "$SAMPLE_COMPUTE_EVERY" \
    --profile-first-n "$PROFILE_FIRST_N" \
    ${BATCH_SIZE_OVERRIDE:+--batch-size $BATCH_SIZE_OVERRIDE} \
    $EXTRA_ARGS \
    >> "$LOG_FILE" 2>&1
