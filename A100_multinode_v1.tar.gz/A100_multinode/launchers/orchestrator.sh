#!/usr/bin/env bash
# orchestrator.sh — sweep over models for exp A (11 runs) or exp B (121 runs).
#
# Usage:
#   bash launchers/orchestrator.sh exp_a [TOTAL_STEPS] [GPUS_PER_NODE]
#   bash launchers/orchestrator.sh exp_b [TOTAL_STEPS] [GPUS_PER_NODE_PER_JOB]
#
# Skips an experiment if its results directory already contains rank00.json
# files for every expected job (so reruns are incremental).

set -eo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

MODE="${1:?Usage: $0 exp_a|exp_b [TOTAL_STEPS] [GPUS]}"
TOTAL_STEPS="${2:-200}"
GPUS="${3:-2}"

MODELS=(gpt2 bert whisper resnet44 resnet110 resnet50 vgg16 googlenet inception3 densenet40_k12 densenet100_k12)

TS=$(date +%Y%m%d_%H%M%S)
SUMMARY_LOG="${ROOT_DIR}/logs/orchestrator_${MODE}_${TS}.log"
mkdir -p "${ROOT_DIR}/logs"

PASS=0; FAIL=0; SKIP=0

run_one() {
    local label="$1"; shift
    echo "----- $label -----" | tee -a "$SUMMARY_LOG"
    local t0=$(date +%s)
    if "$@" >> "$SUMMARY_LOG" 2>&1; then
        echo "[OK]  $label ($(( $(date +%s) - t0 ))s)" | tee -a "$SUMMARY_LOG"
        PASS=$((PASS+1))
    else
        echo "[FAIL] $label ($(( $(date +%s) - t0 ))s)" | tee -a "$SUMMARY_LOG"
        FAIL=$((FAIL+1))
    fi
}

case "$MODE" in
  exp_a)
    for m in "${MODELS[@]}"; do
        run_one "expA_${m}" bash "${ROOT_DIR}/launchers/exp_a.sh" "$m" "$TOTAL_STEPS" "$GPUS"
    done
    ;;
  exp_b)
    for ma in "${MODELS[@]}"; do
        for mb in "${MODELS[@]}"; do
            run_one "expB_${ma}_${mb}" bash "${ROOT_DIR}/launchers/exp_b.sh" "$ma" "$mb" "$TOTAL_STEPS" "$GPUS"
        done
    done
    ;;
  *) echo "unknown mode: $MODE"; exit 2 ;;
esac

echo "" | tee -a "$SUMMARY_LOG"
echo "Sweep done. PASS=$PASS FAIL=$FAIL" | tee -a "$SUMMARY_LOG"
