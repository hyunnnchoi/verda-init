"""Per-worker JSON metrics for multi-node DDP interference experiments.

Each worker (one per global rank) writes its own JSON file under
``<output_dir>/<exp_id>/<job_id>/rank{rank:02d}.json`` so we can later
analyse interference per-worker, per-job, and per-experiment.
"""
import json
import os
from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional


@dataclass
class WorkerMetrics:
    # ── identification ──
    exp_id: str           # e.g. "expB_bert+gpt2_2026-05-01_12-50"
    job_id: str           # e.g. "job0_bert"
    model: str
    partner_job_id: Optional[str]
    partner_model: Optional[str]
    role: str             # "solo" or "pair"
    rank: int             # global rank
    local_rank: int
    world_size: int
    node_rank: int
    nodes_in_world: int
    hostname: str
    visible_gpus: List[int]

    # ── run config ──
    batch_size_per_gpu: int = 0
    total_steps: int = 0
    warmup_steps: int = 0
    sample_compute_every: int = 0

    # ── timing ──
    end_to_end_sec: float = 0.0
    timing: Dict = field(default_factory=dict)            # WorkerTimer.summary()
    iter_times_sec: List[float] = field(default_factory=list)
    compute_times_sec: List[float] = field(default_factory=list)
    compute_step_indices: List[int] = field(default_factory=list)
    losses: List[float] = field(default_factory=list)

    # ── memory ──
    gpu_memory_allocated_mb: float = 0.0
    gpu_memory_reserved_mb: float = 0.0

    # ── env ──
    nccl_env: Dict[str, str] = field(default_factory=dict)
    master_addr: str = ""
    master_port: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        # Round per-step lists for compactness
        d["iter_times_sec"] = [round(t, 6) for t in self.iter_times_sec]
        d["compute_times_sec"] = [round(t, 6) for t in self.compute_times_sec]
        d["losses"] = [round(t, 6) for t in self.losses]
        return d

    def save(self, output_root: str) -> str:
        out_dir = os.path.join(output_root, self.exp_id, self.job_id)
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, f"rank{self.rank:02d}.json")
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
        return path
