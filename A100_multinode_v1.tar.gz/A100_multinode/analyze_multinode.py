#!/usr/bin/env python3
"""Analyze multinode DDP interference experiments.

Inputs:  results/expA_*_<TS>/job0_*/rank*.json    (solo baselines, 11 models × 4 workers)
         results/expB_*_<TS>/{job0,job1}_*/rank*.json  (pair runs, 121 pairs × 8 workers)

Outputs (analysis/):
- per_job_summary.csv          : all jobs aggregated across 4 workers
- exp_a_solo.csv               : solo baseline iter/compute/comm per model
- interference_iter.csv        : 11×11 matrix of iter-time slowdown factor (pair / solo)
- interference_comm.csv        : 11×11 matrix of comm-exposed slowdown factor (pair / solo)
- pair_per_run_long.csv        : long-format per-(main, partner) per-job_role measurements
- symmetry_check.csv           : compare (A,B) vs (B,A) measurements of A-with-B
- model_characteristics.csv    : param count + baseline metrics + max interference observed
- heatmap_iter.png             : interference_iter heatmap
- heatmap_comm.png             : interference_comm heatmap

Notation:
    main = the job we are measuring (job0 in expB_main+partner, job1 in expB_partner+main)
    partner = the co-running job that contends for NIC/PCIe

The 11×11 interference matrix entry (main, partner) averages 8 workers across both runs:
    expB_main+partner   → job0_main   (main on GPUs 0,1, port 29400)
    expB_partner+main   → job1_main   (main on GPUs 2,3, port 29401)
This averages over GPU/port asymmetry.
"""
import argparse
import glob
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

MODELS = [
    "gpt2", "bert", "whisper",
    "resnet44", "resnet110", "resnet50", "vgg16",
    "googlenet", "inception3",
    "densenet40_k12", "densenet100_k12",
]

EXP_A_GLOB = "results/expA_*/job0_*"
EXP_B_GLOB = "results/expB_*/{job0,job1}_*"


def load_rank_json(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def aggregate_workers(job_dir: str) -> dict | None:
    """Mean/std across 4 worker JSONs for one DDP job."""
    rank_files = sorted(glob.glob(os.path.join(job_dir, "rank*.json")))
    if not rank_files:
        return None
    rows = [load_rank_json(p) for p in rank_files]
    iters = np.array([r["timing"]["iter_time_sec"]["mean"] for r in rows])
    comps = np.array([r["timing"]["compute_time_sec"]["mean"] for r in rows])
    comm = np.array([r["timing"]["comm_exposed_sec_mean"] for r in rows])
    iter_p99 = np.array([r["timing"]["iter_time_sec"]["p99"] for r in rows])
    return {
        "model": rows[0]["model"],
        "job_id": rows[0]["job_id"],
        "exp_id": rows[0]["exp_id"],
        "partner_job_id": rows[0].get("partner_job_id"),
        "role": rows[0]["role"],
        "n_workers": len(rows),
        "iter_mean_ms": iters.mean() * 1000,
        "iter_std_ms": iters.std(ddof=0) * 1000,
        "iter_p99_ms": iter_p99.mean() * 1000,
        "compute_mean_ms": comps.mean() * 1000,
        "compute_std_ms": comps.std(ddof=0) * 1000,
        "comm_exposed_ms": max(0.0, iters.mean() - comps.mean()) * 1000,
        "raw_comm_ms": comm.mean() * 1000,
    }


def parse_pair_exp(exp_dir_name: str) -> tuple[str, str] | None:
    """expB_{ma}+{mb}_{ts} -> (ma, mb)."""
    m = re.match(r"expB_(.+)\+(.+)_\d{8}_\d{6}$", exp_dir_name)
    if not m:
        return None
    return m.group(1), m.group(2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--out", default=None, help="output dir (default: <root>/analysis)")
    ap.add_argument("--exp-a-pattern", default="expA_*_20260502_01*",
                    help="glob pattern matching the canonical Exp A sweep dirs")
    ap.add_argument("--exp-b-pattern", default="expB_*_20260502_0[12345]*",
                    help="glob pattern matching the canonical Exp B sweep dirs")
    args = ap.parse_args()

    root = Path(args.root)
    out = Path(args.out) if args.out else (root / "analysis")
    out.mkdir(parents=True, exist_ok=True)
    os.chdir(root)

    # ---------- Exp A: solo baselines ----------
    solo_rows = []
    for d in sorted(glob.glob(f"results/{args.exp_a_pattern}/job0_*")):
        r = aggregate_workers(d)
        if r is None:
            continue
        r["main"] = r["model"]
        r["partner"] = "(solo)"
        r["job_role"] = "solo"
        solo_rows.append(r)
    if not solo_rows:
        print("ERROR: no Exp A solo dirs found", file=sys.stderr)
        sys.exit(1)
    solo_df = pd.DataFrame(solo_rows)

    # Order rows by MODELS list
    solo_df["__order"] = solo_df["main"].map({m: i for i, m in enumerate(MODELS)})
    solo_df = solo_df.sort_values("__order").drop(columns="__order").reset_index(drop=True)

    solo_df_out = solo_df[[
        "main", "iter_mean_ms", "compute_mean_ms", "comm_exposed_ms",
        "iter_std_ms", "iter_p99_ms", "n_workers"
    ]].rename(columns={"main": "model"})
    solo_df_out.to_csv(out / "exp_a_solo.csv", index=False, float_format="%.3f")
    print(f"[exp_a_solo.csv] {len(solo_df_out)} models")
    print(solo_df_out.to_string(index=False, float_format=lambda x: f"{x:.2f}"))
    print()

    solo_iter = dict(zip(solo_df["main"], solo_df["iter_mean_ms"]))
    solo_compute = dict(zip(solo_df["main"], solo_df["compute_mean_ms"]))
    solo_comm = dict(zip(solo_df["main"], solo_df["comm_exposed_ms"]))

    # ---------- Exp B: pair runs ----------
    # For each pair dir, collect both jobs.
    # In expB_ma+mb: job0 measures ma-with-mb (main=ma, partner=mb, role='left')
    #                 job1 measures mb-with-ma (main=mb, partner=ma, role='right')
    pair_rows = []
    for exp_dir in sorted(glob.glob(f"results/{args.exp_b_pattern}")):
        name = os.path.basename(exp_dir)
        parsed = parse_pair_exp(name)
        if parsed is None:
            continue
        ma, mb = parsed
        for job_id, main, partner, side in [
            (f"job0_{ma}", ma, mb, "left"),
            (f"job1_{mb}", mb, ma, "right"),
        ]:
            jdir = os.path.join(exp_dir, job_id)
            r = aggregate_workers(jdir)
            if r is None:
                continue
            r["main"] = main
            r["partner"] = partner
            r["job_role"] = side  # job0 (port 29400, GPUs 0-1) vs job1 (port 29401, GPUs 2-3)
            r["exp_dir"] = name
            pair_rows.append(r)
    pair_df = pd.DataFrame(pair_rows)
    print(f"loaded {len(pair_df)} pair-job entries (expected 121 × 2 = 242)")

    pair_long = pair_df[[
        "exp_dir", "main", "partner", "job_role",
        "iter_mean_ms", "compute_mean_ms", "comm_exposed_ms",
        "iter_std_ms", "iter_p99_ms",
    ]].sort_values(["main", "partner", "job_role"]).reset_index(drop=True)
    pair_long.to_csv(out / "pair_per_run_long.csv", index=False, float_format="%.3f")

    # Per-job summary CSV (all jobs incl solo + pair)
    per_job = pd.concat([
        solo_df.assign(exp_dir=solo_df["exp_id"])[[
            "exp_dir", "main", "partner", "job_role",
            "iter_mean_ms", "compute_mean_ms", "comm_exposed_ms",
            "iter_std_ms", "iter_p99_ms",
        ]],
        pair_long,
    ], ignore_index=True)
    per_job.to_csv(out / "per_job_summary.csv", index=False, float_format="%.3f")

    # ---------- 11×11 Interference matrices ----------
    # entry[main, partner] = mean across both runs (left + right) — each run has 4 workers,
    # so total 8 worker-means per cell.
    grouped = (
        pair_df.groupby(["main", "partner"])
        .agg(
            iter_mean_ms=("iter_mean_ms", "mean"),
            iter_std_ms=("iter_mean_ms", "std"),
            compute_mean_ms=("compute_mean_ms", "mean"),
            comm_exposed_ms=("comm_exposed_ms", "mean"),
            n_runs=("iter_mean_ms", "count"),
        )
        .reset_index()
    )

    # Slowdown factor matrices
    iter_factor = grouped.copy()
    iter_factor["iter_factor"] = iter_factor.apply(
        lambda r: r["iter_mean_ms"] / solo_iter[r["main"]], axis=1
    )
    iter_factor["compute_factor"] = iter_factor.apply(
        lambda r: r["compute_mean_ms"] / solo_compute[r["main"]], axis=1
    )
    # comm factor — solo comm can be tiny → cap on a floor to avoid blowup
    def safe_comm_factor(r):
        s = solo_comm[r["main"]]
        return r["comm_exposed_ms"] / s if s > 1.0 else float("nan")
    iter_factor["comm_factor"] = iter_factor.apply(safe_comm_factor, axis=1)
    iter_factor["comm_delta_ms"] = iter_factor.apply(
        lambda r: r["comm_exposed_ms"] - solo_comm[r["main"]], axis=1
    )

    iter_pivot = iter_factor.pivot(index="main", columns="partner", values="iter_factor").reindex(index=MODELS, columns=MODELS)
    comp_pivot = iter_factor.pivot(index="main", columns="partner", values="compute_factor").reindex(index=MODELS, columns=MODELS)
    comm_pivot = iter_factor.pivot(index="main", columns="partner", values="comm_factor").reindex(index=MODELS, columns=MODELS)
    comm_delta_pivot = iter_factor.pivot(index="main", columns="partner", values="comm_delta_ms").reindex(index=MODELS, columns=MODELS)

    iter_pivot.to_csv(out / "interference_iter.csv", float_format="%.4f")
    comp_pivot.to_csv(out / "interference_compute.csv", float_format="%.4f")
    comm_pivot.to_csv(out / "interference_comm.csv", float_format="%.4f")
    comm_delta_pivot.to_csv(out / "interference_comm_delta_ms.csv", float_format="%.3f")

    print()
    print("=== iter slowdown factor (rows=main, cols=partner) ===")
    print(iter_pivot.to_string(float_format=lambda x: f"{x:.3f}"))

    # ---------- Symmetry: (A,B) job0 main=A vs (B,A) job1 main=A ----------
    sym_rows = []
    pair_grouped_role = pair_df.groupby(["main", "partner", "job_role"]).agg(
        iter_mean_ms=("iter_mean_ms", "mean"),
        comm_exposed_ms=("comm_exposed_ms", "mean"),
    ).reset_index()
    role_pivot = pair_grouped_role.pivot(index=["main", "partner"], columns="job_role", values="iter_mean_ms")
    for (main, partner), row in role_pivot.iterrows():
        left = row.get("left")
        right = row.get("right")
        if pd.notna(left) and pd.notna(right):
            mean = (left + right) / 2
            asym_pct = (left - right) / mean * 100
        else:
            mean = float("nan")
            asym_pct = float("nan")
        sym_rows.append({
            "main": main,
            "partner": partner,
            "iter_left_ms": left,
            "iter_right_ms": right,
            "iter_mean_ms": mean,
            "left_minus_right_pct": asym_pct,
        })
    sym_df = pd.DataFrame(sym_rows)
    sym_df.to_csv(out / "symmetry_check.csv", index=False, float_format="%.3f")
    asym_abs = sym_df["left_minus_right_pct"].abs()
    print()
    print(f"=== left/right asymmetry (job0 vs job1 GPU/port assignment) ===")
    print(f"abs(asym%): mean={asym_abs.mean():.2f}, median={asym_abs.median():.2f}, "
          f"p90={asym_abs.quantile(0.9):.2f}, max={asym_abs.max():.2f}")
    worst = sym_df.iloc[asym_abs.idxmax()] if not asym_abs.empty else None
    if worst is not None:
        print(f"  worst: main={worst['main']} partner={worst['partner']} "
              f"left={worst['iter_left_ms']:.1f} right={worst['iter_right_ms']:.1f} "
              f"({worst['left_minus_right_pct']:+.1f}%)")

    # ---------- Model characteristics & summary ----------
    char_rows = []
    for m in MODELS:
        row_iter = iter_pivot.loc[m]
        max_iter_factor = row_iter.max()
        max_iter_partner = row_iter.idxmax()
        row_comm = comm_delta_pivot.loc[m]
        max_comm_delta = row_comm.max()
        max_comm_partner = row_comm.idxmax()
        char_rows.append({
            "model": m,
            "solo_iter_ms": solo_iter[m],
            "solo_compute_ms": solo_compute[m],
            "solo_comm_ms": solo_comm[m],
            "max_iter_factor": max_iter_factor,
            "worst_partner_iter": max_iter_partner,
            "max_comm_delta_ms": max_comm_delta,
            "worst_partner_comm": max_comm_partner,
            "self_pair_iter_factor": iter_pivot.loc[m, m],
        })
    char_df = pd.DataFrame(char_rows)
    char_df.to_csv(out / "model_characteristics.csv", index=False, float_format="%.4f")

    print()
    print("=== model characteristics & worst-case interference ===")
    print(char_df.to_string(index=False, float_format=lambda x: f"{x:.3f}"))

    # ---------- Heatmaps ----------
    def plot_heatmap(matrix: pd.DataFrame, title: str, fname: str, cmap="RdYlGn_r",
                     center=1.0, vmin=None, vmax=None, fmt="%.2f"):
        fig, ax = plt.subplots(figsize=(11, 9))
        data = matrix.values.astype(float)
        if vmin is None or vmax is None:
            absdev = np.nanmax(np.abs(data - center))
            vmin = center - absdev
            vmax = center + absdev
        im = ax.imshow(data, cmap=cmap, vmin=vmin, vmax=vmax, aspect="auto")
        ax.set_xticks(range(len(MODELS)))
        ax.set_yticks(range(len(MODELS)))
        ax.set_xticklabels(MODELS, rotation=45, ha="right")
        ax.set_yticklabels(MODELS)
        ax.set_xlabel("partner (co-running job)")
        ax.set_ylabel("main (measured job)")
        ax.set_title(title)
        for i in range(len(MODELS)):
            for j in range(len(MODELS)):
                v = data[i, j]
                if np.isfinite(v):
                    ax.text(j, i, fmt % v, ha="center", va="center",
                            color="white" if abs(v - center) > 0.5 * absdev else "black",
                            fontsize=7)
        fig.colorbar(im, ax=ax)
        fig.tight_layout()
        fig.savefig(out / fname, dpi=120)
        plt.close(fig)
        print(f"[saved] {out/fname}")

    plot_heatmap(iter_pivot, "Iter time slowdown factor (pair / solo)",
                 "heatmap_iter.png", center=1.0)
    plot_heatmap(comp_pivot, "Compute time factor (pair / solo) — should be ~1.0",
                 "heatmap_compute.png", center=1.0)
    plot_heatmap(comm_pivot, "comm_exposed factor (pair / solo)",
                 "heatmap_comm.png", center=1.0, fmt="%.2f")
    plot_heatmap(comm_delta_pivot, "comm_exposed delta (pair − solo, ms)",
                 "heatmap_comm_delta.png", cmap="Reds", center=0.0, fmt="%.0f")

    # ---------- Top-N most-affected pairs ----------
    long_factor = iter_factor[["main", "partner", "iter_factor", "comm_delta_ms"]].copy()
    top_iter = long_factor.sort_values("iter_factor", ascending=False).head(10)
    top_comm = long_factor.sort_values("comm_delta_ms", ascending=False).head(10)
    print()
    print("=== top-10 (main, partner) by iter_factor ===")
    print(top_iter.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    print()
    print("=== top-10 (main, partner) by comm_delta_ms ===")
    print(top_comm.to_string(index=False, float_format=lambda x: f"{x:.3f}"))

    print()
    print(f"all outputs → {out}")


if __name__ == "__main__":
    main()
