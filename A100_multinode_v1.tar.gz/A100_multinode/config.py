"""Model and experiment configuration for A100 multi-node interference experiments.

Same 11 models as A100/config.py but tuned for the multi-node case where
the global batch is split across both nodes (so per-GPU batch is preserved).
"""

MODEL_CONFIGS = {
    # ── LLM models (SQuAD dataset, seq_len=512) ──
    "gpt2": {
        "type": "llm",
        "framework": "gpt2",
        "batch_size": 48,
        "max_seq_length": 512,
        "learning_rate": 5e-5,
        "model_name": "gpt2",
    },
    "bert": {
        "type": "llm",
        "framework": "bert",
        "batch_size": 48,
        "max_seq_length": 512,
        "learning_rate": 5e-5,
        "model_name": "bert-base-uncased",
    },
    # ── CNN models on CIFAR-10 (32x32) ──
    "resnet44": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 512,
        "dataset": "cifar10",
        "num_classes": 10,
        "image_size": 32,
        "learning_rate": 0.1,
    },
    "resnet110": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 512,
        "dataset": "cifar10",
        "num_classes": 10,
        "image_size": 32,
        "learning_rate": 0.1,
    },
    "densenet40_k12": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 512,
        "dataset": "cifar10",
        "num_classes": 10,
        "image_size": 32,
        "learning_rate": 0.1,
    },
    "densenet100_k12": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 256,
        "dataset": "cifar10",
        "num_classes": 10,
        "image_size": 32,
        "learning_rate": 0.1,
    },
    # ── CNN models — ImageNet scale, synthetic data ──
    "resnet50": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 256,
        "dataset": "synthetic",
        "num_classes": 1000,
        "image_size": 224,
        "learning_rate": 0.1,
    },
    "vgg16": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 128,
        "dataset": "synthetic",
        "num_classes": 1000,
        "image_size": 224,
        "learning_rate": 0.01,
    },
    "googlenet": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 256,
        "dataset": "synthetic",
        "num_classes": 1000,
        "image_size": 224,
        "learning_rate": 0.1,
    },
    "inception3": {
        "type": "cnn",
        "framework": "cnn",
        "batch_size": 128,
        "dataset": "synthetic",
        "num_classes": 1000,
        "image_size": 299,
        "learning_rate": 0.1,
    },
    # ── Whisper (encoder-decoder, synthetic mel-spectrogram) ──
    "whisper": {
        "type": "speech",
        "framework": "whisper",
        "batch_size": 16,
        "learning_rate": 5e-4,
        "num_mel_bins": 80,
        "mel_seq_len": 3000,
        "max_target_len": 224,
        "vocab_size": 51865,
        "dataset": "synthetic",
    },
}

ALL_MODELS = list(MODEL_CONFIGS.keys())
LLM_MODELS = [k for k, v in MODEL_CONFIGS.items() if v["type"] == "llm"]
CNN_MODELS = [k for k, v in MODEL_CONFIGS.items() if v["type"] == "cnn"]
SPEECH_MODELS = [k for k, v in MODEL_CONFIGS.items() if v["type"] == "speech"]

# Experiment defaults
DEFAULT_TOTAL_STEPS = 200
DEFAULT_WARMUP_STEPS = 10
DEFAULT_COMPUTE_SAMPLE_EVERY = 5  # measure compute-only iter every N measurement steps
