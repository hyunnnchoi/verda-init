# A100_multinode — multi-node DDP interference suite

11 모델 × {solo, pair} 실험을 **두 노드** 환경에서 돌리는 설계.

## 실험 정의

| 실험 | 설명 | 토폴로지 (production) | 횟수 |
|------|------|------------------------|------|
| Exp A | 4-GPU 단일 job, 2 노드에 2+2 worker | NodeA: J0w0,J0w1 / NodeB: J0w2,J0w3 | 11 |
| Exp B | 4-GPU job 두 개 co-located, 노드당 worker 2+2씩 | NodeA: J0w0,J0w1,J1w0,J1w1 / NodeB: J0w2,J0w3,J1w2,J1w3 | 11×11 = 121 |

각 노드는 4×A100 가정. 오늘 1×A100 노드 둘에선 `GPUS_PER_NODE=1`로 스모크만 가능.

## 디렉토리 레이아웃

```
A100_multinode/
├── train.py                  # 통합 trainer (모든 모델 dispatch)
├── config.py                 # MODEL_CONFIGS (A100/config.py 동기화)
├── timing.py                 # WorkerTimer: iter / compute / comm_exposed 분리
├── metrics.py                # WorkerMetrics → per-rank JSON
├── barrier.py                # cross-job 시작 동기화 + done 시그널
├── launchers/
│   ├── launch_worker.sh      # 한 노드의 한 job용 torchrun 래퍼
│   ├── exp_a.sh              # 1 job × 2 노드
│   ├── exp_b.sh              # 2 job × 2 노드
│   └── orchestrator.sh       # 11 또는 121 실험 sweep
├── results/<exp_id>/<job_id>/rank{NN}.json
├── logs/                     # torchrun stdout (NCCL INFO 포함)
└── WORKLOG.md
```

## 사용법

### 단일 실험 (production: 4 GPU/노드)

```bash
# Exp A (1 job, 4 GPUs across 2 nodes)
bash launchers/exp_a.sh bert 200 2

# Exp B (2 jobs, 4 GPUs each, co-located)
bash launchers/exp_b.sh bert gpt2 200 2
```

### 11 + 121 sweep

```bash
bash launchers/orchestrator.sh exp_a 200 2     # 11 solo baselines
bash launchers/orchestrator.sh exp_b 200 2     # 121 pair runs
```

### 오늘 (1 GPU/노드) 스모크

```bash
bash launchers/exp_a.sh resnet44 30 1
GPU_OFFSET_B=0 bash launchers/exp_b.sh resnet44 densenet40_k12 30 1
```

## 측정 방식 — 연산/통신 분리

각 worker는 `WorkerTimer`가 step을 둘러 측정:

1. **Phase 1 — Warmup** (`--warmup-steps`, 기본 10)
   - 정상 DDP step. NCCL 채널 셋업 등 1회성 비용 제거.

2. **Phase 2 — Measurement** (`--total-steps`, 기본 100)
   - 매 step의 wall-clock = `iter_time` (compute + exposed comm)
   - `--sample-compute-every` step마다 추가 1번 `model.no_sync()` step → compute-only baseline
     - DDP 가 backward 의 all_reduce 를 억제하므로 순수 compute time 만 잡음
     - 같은 host/PCIe contention 환경에서 측정되므로 baseline이 공정함

3. **Phase 3 — Keep-running**
   - 본인 측정 끝난 후 peer job 들이 모두 끝낼 때까지 step 계속
   - 모든 peer 의 측정 윈도가 항상 *서로 겹치도록* 보장

해석:
```
comm_exposed = mean(iter_time) - mean(compute_time)
              ≈ critical-path 위에 노출된 통신 시간
              ≈ 정확히 「네트워크가 학습을 얼마나 늦췄나」
```

`--profile-first-n` 가 0보다 크면 첫 N step을 `torch.profiler` 로 떠서 NCCL kernel
duration 합도 함께 기록 (raw comm capacity 추정).

Per-worker JSON에 들어가는 핵심 필드:
- `timing.iter_time_sec` — n, mean, std, min/max, p50/p90/p99
- `timing.compute_time_sec` — 동일 분포
- `timing.comm_exposed_sec_mean`, `comm_exposed_frac`
- `iter_times_sec[]`, `compute_times_sec[]`, `losses[]` — 분석용 raw
- `nccl_kernel_sec_total` — 프로파일러 사용 시
- `gpu_memory_*`, `nccl_env`, `hostname`, `node_rank`, `visible_gpus`

## 포트 / 네트워크

- Job A → port `29400` (BackendAI preopen)
- Job B → port `29401` (BackendAI preopen 목록엔 없으나 inter-node 도달 가능 — TCP 30055 테스트로 확인됨; production 환경에서 재확인 필요)
- Bootstrap: `eth0` (오버레이), 컬렉티브: NCCL이 `mlx5_0` IB plugin (`IBext_v10`) 자동 선택
- 같은 호스트 위 두 컨테이너인지 / 진짜 다른 머신인지에 따라 측정값이 크게 달라짐 — 첫 점검 결과 문서 (`A100/WORKLOG.md` 5/1 entry) 참조

## 알려진 한계

- 오늘 1 GPU/노드 → exp B 정식 토폴로지 불가 (스모크는 GPU 공유로 우회)
- `densenet100_k12` 같이 큰 모델은 batch=512가 OOM 날 수 있음 → `BATCH_SIZE_OVERRIDE` 사용
- `comm_exposed < 0` 인 step (no_sync 가 더 느린 noise) 은 0으로 clamp
- find_unused_parameters=True (googlenet/inception3) 는 추가 sync 비용이 있어 baseline-비교 시 주의
