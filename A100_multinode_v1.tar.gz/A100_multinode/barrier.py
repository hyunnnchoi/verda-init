"""Cross-job filesystem barrier for synchronizing co-located DDP jobs.

When experiment B launches two DDP jobs on the same pair of nodes, we want
both jobs to start their measured training loop at (approximately) the same
wall instant so the interference window is well-defined. Each job's rank 0
writes a "ready" sentinel and waits until *all expected* sentinels exist;
then a NCCL barrier broadcasts the signal to the other ranks of that job.

The barrier directory must live on a path visible to both nodes (e.g. the
shared /home/work mount). For self-pair experiments where two jobs run the
same model, distinguish them via ``job_id`` rather than model name.
"""
import os
import time
from typing import List

import torch
import torch.distributed as dist


def wait_for_jobs(
    job_id: str,
    peer_job_ids: List[str],
    barrier_dir: str,
    rank: int,
    timeout: float = 300.0,
) -> None:
    """Block until this job and all peer jobs have signaled ready.

    Only rank 0 of each job participates in the file signaling. The other
    ranks wait via the in-job NCCL barrier so they synchronize with their
    own rank-0 once the cross-job barrier has cleared.

    Solo / no-peer case (``peer_job_ids`` empty) is a fast no-op.
    """
    if not barrier_dir or not peer_job_ids:
        return

    if rank == 0:
        os.makedirs(barrier_dir, exist_ok=True)
        sentinel = os.path.join(barrier_dir, f"{job_id}.ready")
        with open(sentinel, "w") as f:
            f.write(f"{os.getpid()}\n")

        deadline = time.time() + timeout
        missing = list(peer_job_ids)
        while missing:
            missing = [
                p for p in peer_job_ids
                if not os.path.exists(os.path.join(barrier_dir, f"{p}.ready"))
            ]
            if not missing:
                break
            if time.time() > deadline:
                print(f"[BARRIER] WARNING: {job_id} timed out waiting for {missing} after {timeout}s")
                break
            time.sleep(0.05)
        print(f"[BARRIER] {job_id} synchronized with {peer_job_ids}")

    if dist.is_initialized():
        dist.barrier()


def signal_done(job_id: str, barrier_dir: str, rank: int) -> None:
    """Optional: write a done marker after a job finishes (informational)."""
    if not barrier_dir or rank != 0:
        return
    try:
        with open(os.path.join(barrier_dir, f"{job_id}.done"), "w") as f:
            f.write("done\n")
    except OSError:
        pass
