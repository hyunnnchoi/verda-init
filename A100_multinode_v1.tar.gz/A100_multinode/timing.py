"""Per-worker timing instrumentation for multi-node DDP interference experiments.

Splits a training step into:
  - iter_time:    full DDP step wall time (compute + exposed communication)
  - compute_time: same step body but with DDP all_reduce suppressed via
                  ``model.no_sync()`` — gives us the pure compute baseline
                  *under the same host/PCIe contention environment*
  - comm_exposed = mean(iter_time) - mean(compute_time)

We sample compute-only steps periodically rather than running them every step,
so the cost of the calibration is bounded (default: every 5th measurement step
adds one extra no_sync step).

Optionally, ``profile_first_n_steps`` triggers a one-shot ``torch.profiler``
window over the first N steps and sums NCCL kernel time for a raw-comm
estimate that is independent of compute overlap.
"""
import time
from contextlib import nullcontext
from typing import Callable, List, Optional

import torch
import torch.distributed as dist


class WorkerTimer:
    """Time a DDP training loop with compute/comm decomposition.

    The caller supplies a ``step_fn(use_no_sync: bool) -> loss`` callable that
    runs forward + backward + optimizer.step. When ``use_no_sync=True`` the
    callable must wrap backward in ``model.no_sync()`` so DDP suppresses the
    bucket all_reduces.
    """

    def __init__(
        self,
        ddp_model: torch.nn.Module,
        warmup_steps: int = 10,
        sample_compute_every: int = 5,
        profile_first_n: int = 0,
    ) -> None:
        self.ddp_model = ddp_model
        self.warmup_steps = warmup_steps
        self.sample_compute_every = sample_compute_every
        self.profile_first_n = profile_first_n

        self.step_idx = 0
        self.iter_times: List[float] = []
        self.compute_times: List[float] = []
        self.compute_step_indices: List[int] = []
        self.losses: List[float] = []

        self.nccl_kernel_sec: Optional[float] = None
        self.profiler_total_sec: Optional[float] = None

        self._profiler = None
        if profile_first_n > 0:
            # schedule: skip 0, warmup 1, active = profile_first_n, repeat 1
            self._profiler = torch.profiler.profile(
                activities=[
                    torch.profiler.ProfilerActivity.CPU,
                    torch.profiler.ProfilerActivity.CUDA,
                ],
                schedule=torch.profiler.schedule(
                    wait=0, warmup=1, active=profile_first_n, repeat=1
                ),
                record_shapes=False,
                with_stack=False,
            )
            self._profiler.start()

    # ------------------------------------------------------------------
    def step(self, step_fn: Callable[[bool], torch.Tensor]) -> float:
        """Run one training step. Returns the loss value (float)."""
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        loss = step_fn(False)
        torch.cuda.synchronize()
        wall = time.perf_counter() - t0

        if self.step_idx >= self.warmup_steps:
            self.iter_times.append(wall)
            try:
                self.losses.append(float(loss.detach().item()))
            except Exception:
                self.losses.append(float("nan"))

            measurement_idx = self.step_idx - self.warmup_steps
            if (
                self.sample_compute_every > 0
                and measurement_idx % self.sample_compute_every == 0
            ):
                # Extra compute-only step. We still consume one fresh batch
                # via the same step_fn; the optimizer state will diverge across
                # ranks but for an interference benchmark we don't care about
                # accuracy.
                torch.cuda.synchronize()
                t1 = time.perf_counter()
                step_fn(True)
                torch.cuda.synchronize()
                self.compute_times.append(time.perf_counter() - t1)
                self.compute_step_indices.append(self.step_idx)

        if self._profiler is not None:
            self._profiler.step()

        self.step_idx += 1
        return float(loss.detach().item()) if torch.is_tensor(loss) else float(loss)

    # ------------------------------------------------------------------
    def finalize(self) -> None:
        if self._profiler is None:
            return
        try:
            self._profiler.stop()
        except Exception:
            return
        # Sum NCCL kernel durations (CUDA time) as a raw-comm estimate
        try:
            ka = self._profiler.key_averages()
        except Exception:
            ka = []
        nccl_us = 0.0
        total_us = 0.0
        for evt in ka:
            cuda_us = float(getattr(evt, "self_device_time_total", 0.0))
            if cuda_us == 0.0:
                cuda_us = float(getattr(evt, "self_cuda_time_total", 0.0))
            total_us += cuda_us
            name = (evt.key or "").lower()
            if "nccl" in name or "ncclkernel" in name:
                nccl_us += cuda_us
        self.nccl_kernel_sec = nccl_us / 1e6
        self.profiler_total_sec = total_us / 1e6

    # ------------------------------------------------------------------
    @staticmethod
    def _stats(xs: List[float]) -> dict:
        if not xs:
            return {"n": 0, "mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0,
                    "p50": 0.0, "p90": 0.0, "p99": 0.0}
        ys = sorted(xs)
        n = len(ys)
        mean = sum(ys) / n
        var = sum((y - mean) ** 2 for y in ys) / max(n - 1, 1)
        def q(p: float) -> float:
            k = max(0, min(n - 1, int(round((n - 1) * p))))
            return ys[k]
        return {
            "n": n,
            "mean": mean,
            "std": var ** 0.5,
            "min": ys[0],
            "max": ys[-1],
            "p50": q(0.50),
            "p90": q(0.90),
            "p99": q(0.99),
        }

    def summary(self) -> dict:
        iter_stats = self._stats(self.iter_times)
        comp_stats = self._stats(self.compute_times)
        comm_exposed_mean = max(0.0, iter_stats["mean"] - comp_stats["mean"])
        return {
            "iter_time_sec": iter_stats,
            "compute_time_sec": comp_stats,
            "comm_exposed_sec_mean": comm_exposed_mean,
            "comm_exposed_frac": (
                comm_exposed_mean / iter_stats["mean"] if iter_stats["mean"] > 0 else 0.0
            ),
            "nccl_kernel_sec_total": self.nccl_kernel_sec,
            "profiled_steps": self.profile_first_n,
        }
