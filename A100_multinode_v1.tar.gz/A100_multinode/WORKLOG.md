# WORKLOG — A100_multinode

## [2026-05-02 05:23] Exp A/B sweep 전체 완료 + 인스턴스 보존용 dummy load 가동

### 결과
| 항목 | 값 |
|------|-----|
| Exp A | 11/11 PASS (44 rank JSON) |
| Exp B | 121/121 PASS (968 rank JSON) |
| 총 sweep 소요 | Exp A ~17분, Exp B ~4시간 (01:21–05:23) |
| 실패/에러 | 0 |

### Exp A solo baseline (200 step, 4 GPU/job)
| model | iter (ms) | compute (ms) | comm_exposed (ms) | comm % |
|-------|-----------|--------------|-------------------|--------|
| whisper | 686.1 | 580.7 | 105.4 | 15.4% |
| gpt2 | 553.0 | 480.3 | 72.7 | 13.1% |
| bert | 402.7 | 342.1 | 60.6 | 15.1% |
| resnet50 | 312.5 | 282.2 | 30.3 | 9.7% |
| googlenet | 297.1 | 174.8 | 122.3 | 41.2% |
| densenet100_k12 | 296.9 | 285.1 | 11.8 | 4.0% |
| inception3 | 267.3 | 240.8 | 26.5 | 9.9% |
| vgg16 | 262.5 | 226.2 | 36.3 | 13.8% |
| densenet40_k12 | 155.8 | 145.1 | 10.7 | 6.9% |
| resnet110 | 154.6 | 141.6 | 13.0 | 8.4% |
| resnet44 | 78.7 | 60.5 | 18.3 | 23.2% |

→ googlenet 의 41% 는 `find_unused_parameters=True` 부수 sync 효과 (예상).

### Exp B self-pair (M+M) — 가설 정량 검증
| model | Δiter | Δcompute | comm: solo→pair |
|-------|-------|----------|----------------|
| vgg16 | **+12.8%** | -0.5% | 36 → 71 ms (×1.96) |
| bert | +4.1% | -0.1% | 61 → 77 ms (+27%) |
| gpt2 | +3.5% | -0.9% | 73 → 96 ms (+32%) |
| whisper | +2.7% | -0.5% | 105 → 127 ms (+21%) |
| googlenet | +1.7% | **+14.1%** | 122 → 103 ms |
| densenet100_k12 | +0.7% | +0.2% | 12 → 14 ms |
| densenet40_k12 | +0.4% | -0.1% | 11 → 11 ms |
| resnet50 | +0.3% | +0.0% | 30 → 31 ms |
| inception3 | +0.1% | -0.1% | 27 → 27 ms |
| resnet110 | -0.1% | +0.0% | 13 → 13 ms |
| resnet44 | -6.2% | -2.9% | 18 → 15 ms (noise) |

### 가설 검증 결과
- **"compute 거의 동일, comm만 변화"** — 정성적 입증 ✓
  - 9/11 모델에서 compute Δ < 1%. googlenet(+14%) 만 예외 (find_unused_parameters 의 host-side cost 가 contention 에 노출).
- **comm 영향은 모델 의존성 강함**: vgg16 ×1.96, gpt2/bert/whisper +20~32%, 작은 CNN 들은 거의 0%.
- Iter time 영향 (vgg16 +12.8%, bert +4.1%, gpt2 +3.5%) 모두 comm 변화로 거의 완전히 설명됨 → solo iter * 비교 분석에 충분히 신뢰성 있음.
- resnet44 self-pair 가 -6.2% 인 건 측정 노이즈 (compute 도 -2.9%) 또는 caching/warmup 효과로 추정. 200 step + 4 worker 평균이라 통계적 유의성은 낮은 케이스.

### 변경 사항
| 파일 | 유형 | 설명 |
|------|------|------|
| `results/expA_*_20260502_01*/job0_*/rank*.json` | 생성 | 44개 (11 모델 × 4 worker) |
| `results/expB_*_20260502_0[12345]*/job{0,1}_*/rank*.json` | 생성 | 968개 (121 페어 × 8 worker) |
| `logs/orchestrator_exp_a_20260502_010056.log` | 생성 | Exp A sweep summary |
| `logs/orchestrator_exp_b_20260502_012102.log` | 생성 | Exp B sweep summary |

### 인스턴스 보존
sweep 종료 직후 `/home/work/hyunmokchoi/training_validation.py` 를 양쪽 노드에서 백그라운드 실행:
- main1: PID 203259 (~64 GB VRAM × 4 GPU, 99% util)
- sub1: PID 127278 (동일)
- 로그: `/home/work/hyunmokchoi/training_validation_{main1,sub1}.log`
- 지속 시간: 7,200,000s (~83일)

### TODO (분석 단계)
- 121×11 = 1331 (job, partner) 케이스 → 11×11 interference factor 행렬 (heatmap)
- model 특성 (param count, grad size, baseline iter) 과 comm Δ 의 상관 분석
- raw `iter_times_sec[]` 시계열로 두 job의 step burst 동기화 여부 (NIC contention burst 정성 증거)
- 작성 위치 후보: `analyze_multinode.py`

### 로그
- `logs/orchestrator_exp_a_20260502_010056.log` (PASS=11)
- `logs/orchestrator_exp_b_20260502_012102.log` (PASS=121)
- 모델별 노드별 worker 로그: `logs/expA_*.log`, `logs/expB_*.log` (수백 개)

---

## [2026-05-02 01:00] 8-GPU 환경(4×2) 본 sweep — 환경 재점검 + Exp A 시작

### 실행 환경
| 항목 | 값 |
|------|-----|
| 클러스터 | BackendAI 멀티노드 세션, `main1`(10.100.85.2) ↔ `sub1`(10.100.85.4) |
| GPU/노드 | A100 80GB × **4** (production 토폴로지 ✓) |
| 코어/노드 | nproc=38 |
| Torch / NCCL | torch 2.8.0a0+5228986c39.nv25.05 / NCCL 2.26.5 / IBext_v10 plugin |

### 환경 재점검 (§9.1, §9.2)
| 항목 | main1 | sub1 | 결론 |
|------|-------|------|------|
| machine-id | `368775f62b634ae992f4613009dd1eb5` | **동일** | 같은 물리 호스트 (낮 세션과 동일 결론) |
| uptime | 52d 5:10 | 동일 | |
| /proc/uptime | 4511419.75 | 4511420.16 | |
| GPU UUID | 4개 모두 다름 | 4개 모두 다름 | 8장 disjoint ✓ |
| ping RTT | 0.078 ms (avg) | | |
| NCCL net | `IBext_v10`, `PXN 0 GDR 0` | (smoke 로그 확인) | IB 경로, host bounce |

### 대역폭 재측정 (§9.3, 2-rank)
| 메시지 | algbw (낮) | algbw (오늘) |
|--------|-----------|-------------|
| 1 MiB | 2.98 GB/s | **4.22 GB/s** |
| 16 MiB | 3.62 GB/s | **5.50 GB/s** |
| 1 GiB | 3.69 GB/s | **5.87 GB/s (≈47 Gbit/s)** |

TCP single-stream: 17.32 Gbit/s — NCCL > TCP 가 명확해져 IB 경로의 가치가 정성적으로 확인됨. 다만 같은 물리 호스트 안 컨테이너 사이라 절대값 의의는 제한적.

### 작업 상세
- 환경 점검 완료 (machine-id 동일 — 진짜 멀티-호스트 NIC 경합은 본 세션에서도 검증 불가).
- 그러나 GPU 8장 (4×2) 가용 = production 토폴로지로 Exp A solo + Exp B 121-pair sweep 모두 의미 있는 측정 가능 (컨테이너 간 inter-NIC + GPU disjoint 환경).
- Smoke (50 step, resnet44 self-pair) plumbing 정상: 8 worker JSON 생성, peer barrier 동작.
- Exp A sweep 시작 (orchestrator.sh exp_a 200 2). 11 모델 sequentially.

### 로그
- `logs/2026-05-02_00-48_smoke_NCCL_check.log`
- `logs/2026-05-02_00-49_nccl_bw.log`, `logs/2026-05-02_00-49_tcp_bw.log`
- `logs/orchestrator_exp_a_20260502_010056.log` (진행 중)

---

## [2026-05-01 13:05] A100_multinode 폴더 생성 + 멀티노드 DDP 실험 골격 + 측정 분리 + 스모크

### 실행 환경
| 항목 | 값 |
|------|-----|
| 컨테이너 | `bai-repo:7080/bai/ngc-pytorch:25.05-pytorch2.8-py312-cuda12.9` |
| 클러스터 | BackendAI 멀티노드 세션, `main1` (10.100.85.2) ↔ `sub1` (10.100.85.4) |
| 현재 GPU | A100 80GB × 1 / 컨테이너 (production은 ×4 예정) |
| Torch / NCCL | torch 2.8.0 / NCCL 2.26.5 / IBext_v10 plugin |

### 변경 사항
| 파일 | 유형 | 설명 |
|------|------|------|
| `A100_multinode/__init__.py` | 생성 | 패키지 마커 |
| `A100_multinode/config.py` | 생성 | 11개 모델 (gpt2, bert, whisper, 4 CIFAR CNN, 4 ImageNet CNN) MODEL_CONFIGS |
| `A100_multinode/timing.py` | 생성 | `WorkerTimer` — iter/compute/comm_exposed 분리, 옵션 `torch.profiler` NCCL kernel sum |
| `A100_multinode/metrics.py` | 생성 | `WorkerMetrics` dataclass → per-rank JSON, 통계 + raw lists |
| `A100_multinode/barrier.py` | 생성 | `wait_for_jobs` (cross-job FS barrier), `signal_done` |
| `A100_multinode/train.py` | 생성 | 통합 trainer (모델 dispatch, 3-phase 측정 + keep-running) |
| `A100_multinode/launchers/launch_worker.sh` | 생성 | 한 노드의 한 job용 torchrun 래퍼 |
| `A100_multinode/launchers/exp_a.sh` | 생성 | Exp A (1 job × 2 노드) 런처 |
| `A100_multinode/launchers/exp_b.sh` | 생성 | Exp B (2 jobs × 2 노드 co-located) 런처, `GPU_OFFSET_B` 오버라이드 지원 |
| `A100_multinode/launchers/orchestrator.sh` | 생성 | 11 또는 121 실험 sweep |
| `A100_multinode/README.md` | 생성 | 사용법/측정 설명 |

### 작업 상세

#### 1. 설계 결정
- **통합 train.py**: 기존 4개 train_*.py를 하나로 합침 (모델 wrapper는 기존 ../bert, ../gpt2, ../whisper, ../torch_cnn_benchmarks 그대로 재사용). 측정 로직 단일화.
- **Per-worker JSON**: rank별 한 파일 (`results/<exp_id>/<job_id>/rank{NN}.json`). 4-GPU job 11개 + 121쌍 = 11×4 + 121×8 = 1,012 JSON. 분석 시 worker별 분포 비교 가능.
- **3-phase 측정**: warmup → measurement → keep-running
  - keep-running은 슬로우 job이 끝날 때까지 빠른 job이 step을 계속 돌려서 *모든 측정 윈도가 서로 겹치게* 보장
  - 기존 A100/ 의 primary/interferer 비대칭과 다르게 두 job 모두 fixed steps 측정
- **compute/comm 분리 방법**: `model.no_sync()` 컨텍스트로 backward 의 all_reduce 만 억제, 같은 contention 환경의 compute baseline 측정. `comm_exposed = mean(iter) - mean(compute)`.

#### 2. 스모크 결과 (오늘 1 GPU/노드)

**Exp A — resnet44 30 steps**
| metric | value |
|--------|-------|
| iter_mean | 62.47 ms |
| compute_mean | 58.83 ms |
| comm_exposed | 3.63 ms (5.8%) |
| n_workers | 2 (main1+sub1) |

**Exp B — resnet44 + densenet40_k12 (GPU 공유 모드, 1 GPU/노드)**
| job | iter_mean | compute_mean | comm_exposed |
|-----|-----------|--------------|--------------|
| job0_resnet44 (Solo→Pair) | 62.47 → **128.68 ms** | 58.83 → 124.31 ms | 3.63 → 4.38 ms (3.4%) |
| job1_densenet40_k12 | 306.94 ms | 310.47 ms | 0 (clamp; n=6 noise) |

→ **Pair에서 iter가 2배 됨**. 단, 본 환경은 두 job이 같은 GPU 위에 시간 분할하므로 compute 자체가 영향 받음. 진짜 production (4 GPU/노드) 에선 두 job이 disjoint GPU를 받고 NIC만 공유 → comm_exposed 차이로 깔끔히 분리되어야 함.

#### 3. 검증된 plumbing
- 4 worker 동시 실행 (main1 × 2 + sub1 × 2)
- cross-job barrier (`wait_for_jobs`) 양쪽 ready 확인 후 동시 시작
- keep_running 양쪽 done 확인 후 종료
- per-rank JSON 4개 모두 생성, hostname/node_rank/visible_gpus 정확
- partner_job_id 필드 양방향 일치

### 알려진 한계 / TODO
- 1 GPU/노드 → Exp A는 2-rank로만 검증, Exp B는 GPU 공유 모드로만 검증. 4 GPU/노드 environment 도착하면 정식 토폴로지 (2+2 per node, disjoint GPU/job) 로 재검증 필요
- 포트 29401 inter-node 가용성은 BackendAI preopen 목록에 없음. 30055 TCP 테스트로 도달성 확인했으나 production 환경에서 재확인 필요
- `comm_exposed < 0` 인 step 은 max(0, …) 로 clamp 함 — std 큰 측정에선 일부 정보 손실
- `find_unused_parameters=True` (googlenet/inception3) 는 NCCL 추가 sync 발생 → solo vs pair 비교 시 baseline 잘 잡고 해석

### 자유 의견 / 권고사항
- **iperf3 / nccl-tests 권장**: 이미지에 없으니 `apt install iperf3` 또는 `pip install pynvml`. `nccl-tests/all_reduce_perf` 를 별도 빌드해서 raw NCCL 대역폭 절대값 reference 두면 좋음
- **GDR off**: 현재 `use ring PXN 0 GDR 0` (host bounce). `NCCL_NET_GDR_LEVEL=3` 시도해보면 NIC↔GPU PCIe 직접 가능할 수도 있음
- **포트 풀**: 121 sweep 중 c10d store TIME_WAIT 누적 위험. job_id 별로 다른 포트 (29400, 29401) 만 쓰면 OK지만 같은 (model_a, model_b) 재실행 시 5-10s 텀 권장
- **분석 스크립트**: `analyze_multinode.py` 추후 — per-job iter_mean을 4 worker 평균/std로 집계, solo vs pair interference factor 행렬 (11×11) 생성
- **셋업 자체에 대한 의문**: 첫 점검 결과 두 컨테이너가 *같은 물리 머신* → "멀티노드 NIC 경합" 가설 검증엔 부적합. KT 클러스터 운영자에게 "물리적으로 다른 호스트 + 한 NIC씩 노드에 할당" 보장되는지 문의 권장

### 로그
- `A100_multinode/logs/expA_resnet44_20260501_130319_*.log`
- `A100_multinode/logs/expB_resnet44+densenet40_k12_20260501_130433_*.log`
- 결과: `A100_multinode/results/expA_*/`, `A100_multinode/results/expB_*/`
