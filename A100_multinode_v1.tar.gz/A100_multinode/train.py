"""Unified multi-node DDP trainer for the A100 interference suite.

One process per GPU (launched via ``torchrun``). One job is the union of all
processes that share a single ``--master-port`` and ``--job-id``; co-located
jobs (experiment B) get distinct ports / ids so they form independent NCCL
process groups while sharing host memory, PCIe and NICs.

Phases
------
1. Warmup           — ``warmup_steps`` normal DDP iters (excluded from stats).
2. Measurement      — ``total_steps`` normal iters timed by ``WorkerTimer``.
                      Every ``sample_compute_every`` steps an extra
                      ``model.no_sync()`` step is timed for the compute-only
                      baseline.
3. Keep-running     — once measurement is done, signal peers and keep
                      stepping the model (no measurement) until every peer
                      job has signaled done. Guarantees that *every* job's
                      measurement window overlaps with *every* peer job's
                      measurement window.

Per-worker output: ``<output_root>/<exp_id>/<job_id>/rank{rank:02d}.json``.
"""
from __future__ import annotations

import argparse
import os
import socket
import sys
import time
from contextlib import nullcontext
from pathlib import Path
from typing import Callable, Dict, List, Tuple

import torch
import torch.distributed as dist
import torch.nn as nn
from torch.nn.parallel import DistributedDataParallel as DDP

# Project root on sys.path so we can import bert/, gpt2/, whisper/, etc.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from A100_multinode.config import (  # noqa: E402
    DEFAULT_COMPUTE_SAMPLE_EVERY,
    DEFAULT_TOTAL_STEPS,
    DEFAULT_WARMUP_STEPS,
    MODEL_CONFIGS,
)
from A100_multinode.barrier import signal_done, wait_for_jobs  # noqa: E402
from A100_multinode.metrics import WorkerMetrics  # noqa: E402
from A100_multinode.timing import WorkerTimer  # noqa: E402


# ────────────────────────────────────────────────────────────────────
# Argument parsing
# ────────────────────────────────────────────────────────────────────
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Multi-node DDP interference trainer")
    p.add_argument("--model", required=True, choices=list(MODEL_CONFIGS.keys()))
    p.add_argument("--exp-id", required=True,
                   help="Identifier for this experiment instance (groups all jobs)")
    p.add_argument("--job-id", required=True,
                   help="Unique id for THIS DDP job (e.g. job0_bert / job1_gpt2)")
    p.add_argument("--peer-job-ids", default="",
                   help="Comma-separated job-ids of co-located peers (for cross-job barrier)")
    p.add_argument("--barrier-dir", default="",
                   help="Shared-FS path used for cross-job ready/done sentinels")
    p.add_argument("--output-root", default="./A100_multinode/results")

    p.add_argument("--total-steps", type=int, default=DEFAULT_TOTAL_STEPS)
    p.add_argument("--warmup-steps", type=int, default=DEFAULT_WARMUP_STEPS)
    p.add_argument("--sample-compute-every", type=int, default=DEFAULT_COMPUTE_SAMPLE_EVERY,
                   help="Insert a no_sync compute-only timing step every N measurement steps (0 disables)")
    p.add_argument("--profile-first-n", type=int, default=0,
                   help="If > 0, run torch.profiler over this many steps and report NCCL kernel time")

    p.add_argument("--batch-size", type=int, default=None,
                   help="Override per-GPU batch size from MODEL_CONFIGS")
    p.add_argument("--learning-rate", type=float, default=None)
    p.add_argument("--max-seq-length", type=int, default=512)
    p.add_argument("--num-workers", type=int, default=2)
    p.add_argument("--keep-running-timeout", type=float, default=600.0)
    return p.parse_args()


# ────────────────────────────────────────────────────────────────────
# Model + step factories per framework
# ────────────────────────────────────────────────────────────────────
def _build_bert(cfg: dict, device: torch.device, args) -> nn.Module:
    from bert.config import BERTConfig
    from bert.model import BERTModel
    bcfg = BERTConfig(model_name=cfg["model_name"], batch_size=args.batch_size or cfg["batch_size"],
                      max_seq_length=args.max_seq_length,
                      learning_rate=args.learning_rate or cfg["learning_rate"])
    return BERTModel(bcfg).to(device)


def _build_gpt2(cfg: dict, device: torch.device, args) -> nn.Module:
    from gpt2.config import GPT2Config
    from gpt2.model import GPT2Model
    gcfg = GPT2Config(model_name=cfg["model_name"], batch_size=args.batch_size or cfg["batch_size"],
                      max_seq_length=args.max_seq_length,
                      learning_rate=args.learning_rate or cfg["learning_rate"])
    return GPT2Model(gcfg).to(device)


def _build_whisper(cfg: dict, device: torch.device, args) -> nn.Module:
    from whisper.config import WhisperLocalConfig
    from whisper.model import WhisperModel
    wcfg = WhisperLocalConfig(batch_size=args.batch_size or cfg["batch_size"],
                              learning_rate=args.learning_rate or cfg["learning_rate"])
    return WhisperModel(wcfg).to(device)


def _build_cnn(cfg: dict, device: torch.device, args, model_name: str) -> nn.Module:
    from torch_cnn_benchmarks.models import create_model
    return create_model(model_name, num_classes=cfg["num_classes"]).to(device)


def build_model(model_name: str, cfg: dict, device: torch.device, args) -> Tuple[nn.Module, bool]:
    """Returns (model, needs_find_unused_params)."""
    fw = cfg["framework"]
    if fw == "bert":
        return _build_bert(cfg, device, args), False
    if fw == "gpt2":
        return _build_gpt2(cfg, device, args), False
    if fw == "whisper":
        return _build_whisper(cfg, device, args), False
    if fw == "cnn":
        needs = model_name in ("googlenet", "inception3")
        return _build_cnn(cfg, device, args, model_name), needs
    raise ValueError(f"unknown framework: {fw}")


# ────────────────────────────────────────────────────────────────────
# Dataloader factories
# ────────────────────────────────────────────────────────────────────
def build_dataloader(model_name: str, cfg: dict, args, world_size: int):
    fw = cfg["framework"]
    bs = args.batch_size or cfg["batch_size"]

    if fw in ("bert", "gpt2"):
        from utils.data_utils import get_dataloaders
        train, _, _ = get_dataloaders(
            model_type=fw, tokenizer_name=cfg["model_name"],
            batch_size=bs, max_length=args.max_seq_length,
            num_workers=args.num_workers, use_distributed=(world_size > 1),
        )
        return train

    if fw == "whisper":
        from torch.utils.data import DataLoader, DistributedSampler
        # Reuse the existing synthetic dataset class
        sys.path.insert(0, str(PROJECT_ROOT / "A100"))
        from train_whisper import SyntheticWhisperDataset  # type: ignore
        ds = SyntheticWhisperDataset(
            num_samples=10000, num_mel_bins=cfg.get("num_mel_bins", 80),
            mel_seq_len=cfg.get("mel_seq_len", 3000),
            max_target_len=cfg.get("max_target_len", 224),
            vocab_size=cfg.get("vocab_size", 51865),
        )
        sampler = DistributedSampler(ds, shuffle=True, drop_last=True) if world_size > 1 else None
        return DataLoader(ds, batch_size=bs, sampler=sampler,
                          shuffle=(sampler is None), num_workers=args.num_workers,
                          pin_memory=True, drop_last=True)

    if fw == "cnn":
        from torch.utils.data import DataLoader, DistributedSampler
        sys.path.insert(0, str(PROJECT_ROOT / "A100"))
        from train_cnn import SyntheticDataset, get_cifar10_loader  # type: ignore
        if cfg["dataset"] == "cifar10":
            return get_cifar10_loader(bs, cfg["image_size"], args.num_workers,
                                      distributed=(world_size > 1))
        ds = SyntheticDataset(image_size=cfg["image_size"],
                              num_classes=cfg["num_classes"], length=50000)
        sampler = DistributedSampler(ds, shuffle=True) if world_size > 1 else None
        return DataLoader(ds, batch_size=bs, sampler=sampler,
                          shuffle=(sampler is None), num_workers=args.num_workers,
                          pin_memory=True, drop_last=True)

    raise ValueError(f"unknown framework: {fw}")


# ────────────────────────────────────────────────────────────────────
# Per-framework step (forward + loss)
# ────────────────────────────────────────────────────────────────────
def make_step_fn(model_name: str, cfg: dict, ddp_model: nn.Module,
                 optimizer, device: torch.device, data_iter_holder: Dict, loader,
                 world_size: int):
    """Return ``step_fn(use_no_sync) -> loss`` and a ``next_batch()`` closure."""
    fw = cfg["framework"]
    cnn_loss_fn = nn.CrossEntropyLoss()

    def next_batch():
        try:
            return next(data_iter_holder["it"])
        except StopIteration:
            if world_size > 1 and hasattr(loader, "sampler") and hasattr(loader.sampler, "set_epoch"):
                loader.sampler.set_epoch(int(time.time()))
            data_iter_holder["it"] = iter(loader)
            return next(data_iter_holder["it"])

    def step_fn(use_no_sync: bool) -> torch.Tensor:
        batch = next_batch()
        ctx = ddp_model.no_sync() if use_no_sync and hasattr(ddp_model, "no_sync") else nullcontext()
        with ctx:
            if fw in ("bert", "gpt2"):
                input_ids = batch["input_ids"].to(device, non_blocking=True)
                attn = batch["attention_mask"].to(device, non_blocking=True)
                labels = batch["labels"].to(device, non_blocking=True)
                out = ddp_model(input_ids=input_ids, attention_mask=attn, labels=labels)
                loss = out["loss"]
            elif fw == "whisper":
                feats = batch["input_features"].to(device, non_blocking=True)
                dec_ids = batch["decoder_input_ids"].to(device, non_blocking=True)
                labels = batch["labels"].to(device, non_blocking=True)
                out = ddp_model(input_features=feats, decoder_input_ids=dec_ids, labels=labels)
                loss = out["loss"]
            else:  # cnn
                inputs, targets = batch
                inputs = inputs.to(device, non_blocking=True)
                targets = targets.to(device, non_blocking=True)
                outputs = ddp_model(inputs)
                if isinstance(outputs, tuple):  # inception aux
                    outputs = outputs[0]
                loss = cnn_loss_fn(outputs, targets)

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
        # optimizer.step() runs whether or not no_sync was active
        optimizer.step()
        return loss

    return step_fn


# ────────────────────────────────────────────────────────────────────
# Optimizer factory
# ────────────────────────────────────────────────────────────────────
def build_optimizer(model: nn.Module, cfg: dict, lr: float):
    fw = cfg["framework"]
    if fw in ("bert", "gpt2", "whisper"):
        from torch.optim import AdamW
        no_decay = ("bias", "LayerNorm.weight", "layer_norm.weight")
        decay_p, no_decay_p = [], []
        for n, p in model.named_parameters():
            (no_decay_p if any(nd in n for nd in no_decay) else decay_p).append(p)
        return AdamW([
            {"params": decay_p, "weight_decay": 0.01},
            {"params": no_decay_p, "weight_decay": 0.0},
        ], lr=lr)
    return torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=1e-4)


# ────────────────────────────────────────────────────────────────────
# Phase 3: keep-running until all peers report done
# ────────────────────────────────────────────────────────────────────
def keep_running(step_fn: Callable, peer_job_ids: List[str], barrier_dir: str,
                 rank: int, model_name: str, timeout: float) -> int:
    """After our measurement is done, keep stepping until every peer is done.

    Rank 0 polls the filesystem for peer ``.done`` sentinels every ~1s; the
    decision is broadcast to the other ranks via a 1-element CUDA tensor each
    step (cheaper than a full barrier).
    """
    if not peer_job_ids:
        return 0
    deadline = time.time() + timeout
    extra_steps = 0
    while True:
        if rank == 0:
            done = all(
                os.path.exists(os.path.join(barrier_dir, f"{p}.done"))
                for p in peer_job_ids
            )
            stop_flag = 1 if done or time.time() > deadline else 0
        else:
            stop_flag = 0
        t = torch.tensor([stop_flag], device="cuda")
        dist.broadcast(t, src=0)
        if t.item() == 1:
            break
        # one extra (uncounted) iter to keep generating interference
        with torch.no_grad():
            pass  # placeholder
        try:
            step_fn(False)
        except Exception as e:
            if rank == 0:
                print(f"[{model_name}] keep_running step failed: {e}")
            break
        extra_steps += 1
    return extra_steps


# ────────────────────────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────────────────────────
def main() -> None:
    args = parse_args()
    cfg = MODEL_CONFIGS[args.model]
    bs = args.batch_size or cfg["batch_size"]
    lr = args.learning_rate or cfg["learning_rate"]

    # ── DDP init ──
    dist.init_process_group(backend="nccl")
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ["LOCAL_RANK"])
    node_rank = int(os.environ.get("GROUP_RANK", os.environ.get("NODE_RANK", 0)))
    nodes_in_world = int(os.environ.get("WORLD_SIZE", world_size)) // max(
        int(os.environ.get("LOCAL_WORLD_SIZE", 1)), 1
    )
    torch.cuda.set_device(local_rank)
    device = torch.device(f"cuda:{local_rank}")
    visible_gpus = [int(g) for g in os.environ.get("CUDA_VISIBLE_DEVICES", "0").split(",")]
    hostname = socket.gethostname()
    peer_ids = [p for p in args.peer_job_ids.split(",") if p]

    if rank == 0:
        print(f"[{args.job_id}] model={args.model} world={world_size} "
              f"nodes={nodes_in_world} bs/gpu={bs} peers={peer_ids}")

    # ── Model + DDP ──
    model, needs_find_unused = build_model(args.model, cfg, device, args)
    if world_size > 1:
        ddp_model = DDP(model, device_ids=[local_rank],
                        find_unused_parameters=needs_find_unused)
    else:
        ddp_model = model

    loader = build_dataloader(args.model, cfg, args, world_size)
    optimizer = build_optimizer(model, cfg, lr)
    data_holder = {"it": iter(loader)}
    step_fn = make_step_fn(args.model, cfg, ddp_model, optimizer, device,
                           data_holder, loader, world_size)

    # ── Cross-job barrier (start together with peers) ──
    wait_for_jobs(args.job_id, peer_ids, args.barrier_dir, rank)

    # ── Warmup ──
    ddp_model.train()
    e2e_start = time.perf_counter()
    for _ in range(args.warmup_steps):
        step_fn(False)
    torch.cuda.synchronize()
    if rank == 0:
        print(f"[{args.job_id}] warmup done ({args.warmup_steps} steps)")

    # ── Measurement ──
    timer = WorkerTimer(
        ddp_model,
        warmup_steps=0,  # warmup already happened above
        sample_compute_every=args.sample_compute_every,
        profile_first_n=args.profile_first_n,
    )
    last_loss = float("nan")
    for s in range(args.total_steps):
        last_loss = timer.step(step_fn)
        if rank == 0 and (s % 10 == 0 or s == args.total_steps - 1):
            wall = timer.iter_times[-1] if timer.iter_times else 0.0
            print(f"  [{args.job_id}] step {s:>4d}/{args.total_steps} "
                  f"loss={last_loss:.4f} iter={wall*1000:.1f}ms")
    timer.finalize()
    torch.cuda.synchronize()

    # Signal we are done with measurement, then keep generating interference
    signal_done(args.job_id, args.barrier_dir, rank)
    extra = keep_running(step_fn, peer_ids, args.barrier_dir, rank,
                         args.model, args.keep_running_timeout)
    if rank == 0:
        print(f"[{args.job_id}] kept running {extra} extra steps after measurement")

    # ── Persist per-worker metrics ──
    e2e = time.perf_counter() - e2e_start
    nccl_env = {k: v for k, v in os.environ.items() if k.startswith("NCCL_")}
    wm = WorkerMetrics(
        exp_id=args.exp_id,
        job_id=args.job_id,
        model=args.model,
        partner_job_id=peer_ids[0] if peer_ids else None,
        partner_model=None,  # filled by orchestrator post-hoc if desired
        role="pair" if peer_ids else "solo",
        rank=rank,
        local_rank=local_rank,
        world_size=world_size,
        node_rank=node_rank,
        nodes_in_world=nodes_in_world,
        hostname=hostname,
        visible_gpus=visible_gpus,
        batch_size_per_gpu=bs,
        total_steps=args.total_steps,
        warmup_steps=args.warmup_steps,
        sample_compute_every=args.sample_compute_every,
        end_to_end_sec=e2e,
        timing=timer.summary(),
        iter_times_sec=timer.iter_times,
        compute_times_sec=timer.compute_times,
        compute_step_indices=timer.compute_step_indices,
        losses=timer.losses,
        gpu_memory_allocated_mb=torch.cuda.max_memory_allocated(device) / (1024 ** 2),
        gpu_memory_reserved_mb=torch.cuda.max_memory_reserved(device) / (1024 ** 2),
        nccl_env=nccl_env,
        master_addr=os.environ.get("MASTER_ADDR", ""),
        master_port=os.environ.get("MASTER_PORT", ""),
    )
    path = wm.save(args.output_root)
    if rank == 0:
        print(f"[{args.job_id}] rank-0 wrote {path}")
        s = wm.timing
        print(f"[{args.job_id}] iter_mean={s['iter_time_sec']['mean']*1000:.2f}ms "
              f"compute_mean={s['compute_time_sec']['mean']*1000:.2f}ms "
              f"comm_exposed={s['comm_exposed_sec_mean']*1000:.2f}ms "
              f"({s['comm_exposed_frac']*100:.1f}%)")

    dist.destroy_process_group()


if __name__ == "__main__":
    main()
